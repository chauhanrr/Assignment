package com.automation.assignment;

import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class TestLogin {
	public static WebDriver driver;
	
	@Parameters({ "url", "userName", "password" })
	@Test
	public void loginTestScenario(String url, String userName, String Password) throws InterruptedException {
		
		driver.navigate().to(url);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Assert.assertTrue(true, "Test Scenarios");
		//Add Wait for web element displayed
		By userNameLocator = By.xpath("//div[@id='sfdc_username_container']//input");
		By passwordLocator = By.xpath("//div[@id='sfdc_password_container']//input");
		By loginButton = By.xpath("//button[text()='Log in']");
		WebElement usernamefield = driver.findElement(userNameLocator);
		if (!usernamefield.isDisplayed())
			Assert.assertTrue(false, "URL load failed");
		driver.findElement(userNameLocator).sendKeys(userName);
		driver.findElement(passwordLocator).sendKeys(Password);
		driver.findElement(loginButton).click();
	}
}
